import requests

url = "http://localhost:8080"
try:
    response = requests.get(url)
    if response.status_code == 200:
        print("✅ App is UP")
    else:
        print("⚠️ App is DOWN - Status:", response.status_code)
except:
    print("❌ App not reachable")
