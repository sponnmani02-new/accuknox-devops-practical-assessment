import psutil

cpu = psutil.cpu_percent(1)
mem = psutil.virtual_memory().percent
disk = psutil.disk_usage('/').percent

if cpu > 80 or mem > 80 or disk > 80:
    print("⚠️ System Alert! High usage detected")
else:
    print("✅ System Healthy")
