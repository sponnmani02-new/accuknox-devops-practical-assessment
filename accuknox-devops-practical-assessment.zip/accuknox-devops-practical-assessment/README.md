# Accuknox DevOps Trainee Practical Assessment

This repository contains the completed practical assessment for the **Accuknox DevOps Trainee** program.

---

## 🚀 Problem Statement 1 – Containerisation and Deployment of Wisecow Application

**Objective:**  
Containerize and deploy the [Wisecow App](https://github.com/nyrahul/wisecow) on a Kubernetes cluster (Minikube/Kind) with TLS and CI/CD.

**Included Files:**
- `Dockerfile` – Container image for Wisecow app.
- `deployment.yaml` – Kubernetes deployment configuration.
- `service.yaml` – Service configuration to expose the app.
- `.github/workflows/ci.yml` – GitHub Actions workflow for CI/CD automation.

**Pipeline Workflow:**
- On every push to `main`:
  - Builds Docker image.
  - Pushes to Docker Hub (or container registry).
  - Deploys latest image to Kubernetes.

---

## ⚙️ Problem Statement 2 – Automation Scripts

Two automation scripts are included:

1. **System Health Monitor** –  
   Monitors CPU, memory, and disk usage, logs alerts if thresholds exceed limits.  
   📄 File: `system_health_monitor.sh`

2. **Application Health Checker** –  
   Checks if an app URL is reachable and returns “UP” or “DOWN” status.  
   📄 File: `app_health_checker.py`

---

## 🛡️ Problem Statement 3 – KubeArmor Zero-Trust Policy

**Objective:**  
Apply a zero-trust KubeArmor policy to secure the Wisecow workload.

**Included Files:**
- `kubearmor-policy.yaml` – Example KubeArmor policy (blocks access to /etc/passwd).
- `screenshot-kubearmor-violation.png` – Placeholder screenshot showing a simulated violation.

---

## 📂 Repository Structure

---

## 👩‍💻 Author
**Ponnmani S**  
📧 ponnmanisenthil@gmail.com  
**Accuknox DevOps Trainee Assessment – 2025**
